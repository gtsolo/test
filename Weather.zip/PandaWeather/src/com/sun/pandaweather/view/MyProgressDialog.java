package com.sun.pandaweather.view;

import com.sun.pandaweather.R;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
/**
 * 自定义进度条
 * @author sun
 */
public class MyProgressDialog extends Dialog {

	public MyProgressDialog(Context context, boolean cancelable,
			OnCancelListener cancelListener) {
		super(context, cancelable, cancelListener);
	}

	public MyProgressDialog(Context context, int theme) {
		super(context, theme);
	}

	public MyProgressDialog(Context context) {
		super(context);
	}
	
	@Override
	public void onBackPressed() {
		super.onBackPressed();
	}
	
	public static MyProgressDialog createProgressDialog(Context context,String message){
		MyProgressDialog progress=new MyProgressDialog(context, R.style.dialog);
		progress.requestWindowFeature(Window.FEATURE_NO_TITLE);
		View view=LayoutInflater.from(context).inflate(R.layout.dialog_progress, null);
		TextView tvMessage = (TextView)view.findViewById(R.id.message);
        tvMessage.setText(message);
        progress.setContentView(view);
		return progress;
	}
}
