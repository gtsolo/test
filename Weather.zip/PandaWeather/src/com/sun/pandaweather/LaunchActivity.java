package com.sun.pandaweather;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;

import net.sf.json.xml.XMLSerializer;

import org.apache.http.HttpEntity;
import org.apache.http.ParseException;
import org.apache.http.client.entity.GzipDecompressingEntity;
import org.apache.http.util.EntityUtils;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.LinearLayout.LayoutParams;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.location.LocationClientOption.LocationMode;
import com.google.gson.GsonBuilder;
import com.sun.pandaweather.base.MHttpEntity;
import com.sun.pandaweather.bean.ResponseWrapper;
import com.sun.pandaweather.bean.SendDataBean;
import com.sun.pandaweather.view.MyProgressDialog;

public class LaunchActivity extends Activity {

	public static ResponseWrapper response;// 数据结构的对象
	public static final int succeed = 1;
	public static final int fail = 2;
	public static final int nonet = 3;
	public String normalDistrict;
	public String normalCity;
	public LocationClient mLocationClient = null;
	public BDLocationListener mListener;
	private Dialog dialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.launch_activity);

		mLocationClient = new LocationClient(this.getApplicationContext());
		mListener = new MyLocationListener();
		mLocationClient.registerLocationListener(mListener);// 注册监听函数
		LocationClientOption option = new LocationClientOption();
		option.setLocationMode(LocationMode.Hight_Accuracy);
		option.setIsNeedAddress(true);
		mLocationClient.setLocOption(option);
		mLocationClient.start();

		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					Thread.sleep(2000);// 注：异步线程中不能设置UI

				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				sendRequest();
			}
		}).start();
	}
	
	/**
	 * XML数据转化为json格式
	 * 
	 * @param xmlstr
	 * @return
	 */
	private String XML2Json(String xmlstr) {
		//创建 XMLSerializer对象
        XMLSerializer xmlSerializer = new XMLSerializer();
        //将xml转为json（注：如果是元素的属性，会在json里的key前加一个@标识）
        String result = xmlSerializer.read(xmlstr).toString();
        result = result.replaceAll("\\[\\]","\"\"");//空数组替换为空字符串
        return result;
	}
	

	private void sendRequest() {
		Log.i("TAG", System.currentTimeMillis()
				+ "System.currentTimeMillis()222");
		String getData = null;
		MHttpEntity mhe = null;
		try {
			SendDataBean.setCity(normalDistrict);
			//定位地址
			Log.e("TAG", normalDistrict + "==>>normalDistrict");
			//mhe = MHttpEntity.sendhttpclient(SendDataBean.getData());//百度 API 
			//mhe = MHttpEntity.sendhttpclient(SendDataBean.getDataK780());//
			//mhe = MHttpEntity.sendhttpclient(SendDataBean.getDataEtouch());//
			mhe = MHttpEntity.sendhttpclient(SendDataBean.getDataEtouchFull());//
			//判断天气数据获取是否成功
		/*	if(mhe.getHentity()!=null) {
				getData = EntityUtils.toString(mhe.getHentity());
				GsonBuilder gson = new GsonBuilder();//
				response = gson.create().fromJson(getData,
						ResponseWrapper.class);
				if("302".equals( response.getStatus())) {
					//请求超时，百度天气API服务器故障，请稍候再试
					mhe = MHttpEntity.sendhttpclient(SendDataBean.getDataK780());//sun
				}
			}*/
			if (mhe.getHentity() != null) {
				if("gzip".equalsIgnoreCase(mhe.getHentity().getContentEncoding().getValue())){  
					//GzipDecompressingEntity entity=new GzipDecompressingEntity(mhe.getHentity()); 
					getData = mhe.getMessage().obj.toString();//getStringFromGZIP(mhe.getHentity());//EntityUtils.toString(entity);                 
                } else {
                	getData = EntityUtils.toString(mhe.getHentity());
                }
				//XML格式的数据转化为json格式
				getData = XML2Json(getData);
				GsonBuilder gson = new GsonBuilder();//
				response = gson.create().fromJson(getData, ResponseWrapper.class);//json数据序列化为Java对象
				
				//Log.i("TAG", response.getCity() + "-->response.getError()");
				/*if (response.getError() == -3) {
					Log.e("TAG", normalDistrict + "==>>normalDistrict222");
					SendDataBean.setCity(normalDistrict);
					mhe = MHttpEntity.sendhttpclient(SendDataBean.getData());
					if (mhe.getHentity() != null) {
						getData = EntityUtils.toString(mhe.getHentity());
						Log.i("TAG", getData + "-->getData");
					}
					if (response.getError() == -3) {
						SendDataBean.setCity(normalCity);
						Log.e("TAG", normalCity + "==>>normalCity");
						mhe = MHttpEntity
								.sendhttpclient(SendDataBean.getData());
						if (mhe.getHentity() != null) {
							Log.e("TAG", mhe.getHentity()
									+ "==>>mhe.getHentity()");
							getData = EntityUtils.toString(mhe.getHentity()); //sun
							Log.i("TAG", getData + "-->getData");
						}
					}
				}
				*/
				mhe.getMessage().obj = getData;
			}
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		handler.sendMessage(mhe.getMessage());// 使用Handler对网络状态做处理
	}

	/**
	 * 对网络连接状态做处理
	 */
	Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			if (dialog != null) {
				dialog.dismiss();
			}
			if (msg != null)
				switch (msg.arg1) {
				case succeed:// 与服务器连接成功，则传递数据并跳转
					Intent intent = new Intent(LaunchActivity.this,
							HomePagerActivity.class);
					if (msg.obj != null)
						intent.putExtra("weather_data", (String) msg.obj);
					else
					{
						//请求超时，天气API服务器故障，请稍候再试
						Toast.makeText(LaunchActivity.this,
								getString(R.string.BAIDU_API_fail), Toast.LENGTH_SHORT)
								.show();
						return;
					}
					intent.putExtra("normal_city", normalCity);
					 
					startActivity(intent);
					finish();
					break;
				case fail:// 与服务器连接失败，弹出错误提示Toast
					Toast.makeText(LaunchActivity.this,
							getString(R.string.net_fail), Toast.LENGTH_SHORT)
							.show();
					Message Mesg = Message.obtain();
					Mesg.arg1 = nonet;// Handler机制，同抽奖类APP
					handler.sendMessageDelayed(Mesg, 2000);// 延迟发送
					
					break;
				case nonet:
					finish();// 2秒后关闭页面
					break;
				}
		}
	};

	/**
	 * 拦截返回键
	 */
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	public class MyLocationListener implements BDLocationListener {

		@Override
		public void onReceiveLocation(BDLocation location) {
			if (location != null) {
				normalDistrict = location.getDistrict();
				normalCity = location.getCity();
				Log.i("TAG", normalCity + "---->>normalCity");
				if (normalCity == null) {
					normalCity="南京";
					Toast.makeText(LaunchActivity.this, "定位失败，默认为南京", Toast.LENGTH_LONG).show();	
				}
			} else {
				String[] str = normalCity.split("市");
				normalCity = str[0];
				if("南京".equals(normalCity)){
					Toast.makeText(LaunchActivity.this, "定位失败，默认为南京", Toast.LENGTH_LONG).show();
				}
			}
		}
	}
}

