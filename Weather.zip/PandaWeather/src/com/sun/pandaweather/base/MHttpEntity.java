package com.sun.pandaweather.base;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import java.util.zip.GZIPInputStream;

import net.sf.json.xml.XMLSerializer;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;

import android.net.Uri;
import android.os.Message;
import android.util.Log;

public class MHttpEntity {
	
	private Message message;
	private HttpEntity hentity;
	public static final int succeed = 1;
	public static final int fail = 2;
	public static final int nonet = 3;
	public String result;//获取的返回结果
	
	public Message getMessage() {
		return message;
	}
	public void setMessage(Message message) {
		this.message = message;
	}
	public HttpEntity getHentity() {
		return hentity;
	}
	public void setHentity(HttpEntity hentity) {
		this.hentity = hentity;
	}

	private static String getStringFromGZIP(HttpEntity entity) {  
        String jsonString = null;  
        try {  
            InputStream is = entity.getContent();  
            BufferedInputStream bis = new BufferedInputStream(is);  
            bis.mark(2);  
            // 取前两个字节  
            byte[] header = new byte[2];  
            int result = bis.read(header);  
            // reset输入流到开始位置  
            bis.reset();  
            // 判断是否是GZIP格式  
            int headerData = getShort(header);  
            if (result != -1 && headerData == 0x1f8b) {  
                is = new GZIPInputStream(bis);  
            } else {  
                is = bis;  
            }  
            InputStreamReader reader = new InputStreamReader(is, "utf-8");  
            char[] data = new char[100];  
            int readSize;  
            StringBuffer sb = new StringBuffer();  
            while ((readSize = reader.read(data)) > 0) {  
                sb.append(data, 0, readSize);  
            }  
            jsonString = sb.toString();  
            bis.close();  
            reader.close();  
        } catch (Exception e) {  
            Log.e("HttpTask", e.toString(), e);  
        }  
        return jsonString;  
    }  
  
    private static int getShort(byte[] data) {  
        return (int) ((data[0] << 8) | data[1] & 0xFF);  
    }
    
	public static MHttpEntity sendhttpclient(String str) {
		MHttpEntity mhe = new MHttpEntity();
		Message Mesg = Message.obtain();
		HttpEntity he = null;
		HttpClient hClient = new DefaultHttpClient();// 实例化得到一个网络连接对象
		HttpConnectionParams.setConnectionTimeout(hClient.getParams(), 5000);//连接超时设置
		 
		String mstr = Uri.decode(str);// 将String类型转为uri.有中文则必有此句。
		HttpGet hget = new HttpGet(mstr);// 创建Http请求(get请求)
		
		try {
			HttpResponse re = hClient.execute(hget);// 执行一个请求
			//re.setHeader("Content-type", "text/html;charset=UTF-8");
			if (re.getStatusLine().getStatusCode() == 200) {
				he = re.getEntity();// 获得数据实体
				Mesg.arg1 = succeed;// 保存网络状态
				Mesg.obj = getStringFromGZIP(he);//直接解压缩
				
			} else {
				Mesg.arg1 = fail;// 保存网络状态
			}
		} catch (SocketTimeoutException e) {
			Mesg.arg1 = fail;
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			Mesg.arg1 = fail;
			e.printStackTrace();
		} catch (IOException e) {
			Mesg.arg1 = fail;
			e.printStackTrace();
		}
		mhe.setMessage(Mesg);
		mhe.setHentity(he);
		return mhe;
	}
	
	/*
	private static String XML2Json(String xmlstr) {
		//创建 XMLSerializer对象
        XMLSerializer xmlSerializer = new XMLSerializer();
        //将xml转为json（注：如果是元素的属性，会在json里的key前加一个@标识）
        String result = xmlSerializer.read(xmlstr).toString();
        return result;
	}
	
	public static void main(String[] args) {
		MHttpEntity entity = sendhttpclient(com.sun.pandaweather.bean.SendDataBean.getDataEtouchFull());
		HttpEntity he = entity.getHentity();
		try {
			String xmldata = EntityUtils.toString(he);
			System.out.println(xmldata);
			String jsondata = XML2Json(xmldata);
			System.out.println(jsondata);
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	*/
}
