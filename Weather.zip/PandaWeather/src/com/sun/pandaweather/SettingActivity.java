package com.sun.pandaweather;

import android.app.Activity;
import android.app.PendingIntent;
import android.app.PendingIntent.CanceledException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class SettingActivity extends Activity {
	private ImageView mGPS;
	private SharedPreferences prefs;
	private Context ctx;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setting);
		ctx = SettingActivity.this;
		mGPS = (ImageView) findViewById(R.id.iv_onoff);
		isOnff(ctx);

		mGPS.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
					Intent intent = new Intent(
							Settings.ACTION_LOCATION_SOURCE_SETTINGS);
					startActivityForResult(intent, 0);
			}
		});
	}

	@Override
	protected void onRestart() {
		isOnff(ctx);
		super.onRestart();
	}

	/** 判断GPS开关 */
	protected void isOnff(Context ctx) {
		boolean gps = isOpen(ctx);
		if (gps) {
			mGPS.setBackgroundResource(R.drawable.switch_on);
		} else {
			mGPS.setBackgroundResource(R.drawable.switch_off);
		}
	}

	/**
	 * 判断GPS是否开启
	 * 
	 * @param context
	 * @return true 表示开启
	 */
	public static final boolean isOpen(final Context context) {
		LocationManager locationManager = (LocationManager) context
				.getSystemService(Context.LOCATION_SERVICE);
		// 通过GPS卫星定位，定位级别可以精确到街（通过24颗卫星定位，在室外和空旷的地方定位准确、速度快）
		boolean gps = locationManager
				.isProviderEnabled(LocationManager.GPS_PROVIDER);

		if (gps) {
			return true;
		}

		return false;
	}

}
