package com.sun.pandaweather.bean;

import java.util.List;

public class ResponseWrapper {
	
	/** 基本信息  **/
	private String city;//城市
	private String updatetime;//天气更新时间
	private String wendu;//温度
	private String fengli;//风力
	private String shidu;//湿度
	private String fengxiang;//风向
	private String sunrise_1;//日出
	private String sunset_1;//日落
	/** environment信息 **/
	private Environment environment;
	/**  警告信息  ,非必有项 **/
	//private Alarm alarm;
	/** 昨天天气 **/
	private Yesterday yesterday;
	/** 未来5天天气 **/
	private List<Forecast> forecast;//天气预报信息
	/** 生活指数 **/
	private List<Zhishus> zhishus;
	
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getUpdatetime() {
		return updatetime;
	}
	public void setUpdatetime(String updatetime) {
		this.updatetime = updatetime;
	}
	public String getWendu() {
		return wendu;
	}
	public void setWendu(String wendu) {
		this.wendu = wendu;
	}
	public String getFengli() {
		return fengli;
	}
	public void setFengli(String fengli) {
		this.fengli = fengli;
	}
	public String getShidu() {
		return shidu;
	}
	public void setShidu(String shidu) {
		this.shidu = shidu;
	}
	public String getFengxiang() {
		return fengxiang;
	}
	public void setFengxiang(String fengxiang) {
		this.fengxiang = fengxiang;
	}
	public String getSunrise_1() {
		return sunrise_1;
	}
	public void setSunrise_1(String sunrise_1) {
		this.sunrise_1 = sunrise_1;
	}
	public String getSunset_1() {
		return sunset_1;
	}
	public void setSunset_1(String sunset_1) {
		this.sunset_1 = sunset_1;
	}
	public Environment getEnvironment() {
		return environment;
	}
	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}
	/*public Alarm getAlarm() {
		return alarm;
	}
	public void setAlarm(Alarm alarm) {
		this.alarm = alarm;
	}*/
	public Yesterday getYesterday() {
		return yesterday;
	}
	public void setYesterday(Yesterday yesterday) {
		this.yesterday = yesterday;
	}
	public List<Forecast> getForecast() {
		return forecast;
	}
	public void setForecast(List<Forecast> forecast) {
		this.forecast = forecast;
	}
	public List<Zhishus> getZhishus() {
		return zhishus;
	}
	public void setZhishus(List<Zhishus> zhishus) {
		this.zhishus = zhishus;
	}
	
	
	
	/**  百度天气API返回的字段   
	
	private int error;//错误次数
	private String status;//返回结果状态信息
	private String date;//当前时间
	private List<WeatherBean> results;//天气预报信息	
	
	public int getError() {
		return error;
	}
	public void setError(int error) {
		this.error = error;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public List<WeatherBean> getResults() {
		return results;
	}
	public void setResults(List<WeatherBean> results) {
		this.results = results;
	}
	   **/
}
