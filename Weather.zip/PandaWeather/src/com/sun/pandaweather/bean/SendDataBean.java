package com.sun.pandaweather.bean;


public class SendDataBean {

	public static String city = "";
	public static String json = "json";
	public static String ak = "iGs8rFvzh1e8c7C9DjXT5toK";
	//public static String ak = "Bhp2tTIKtYagVjT1SGqKRamT";
	
	public static void setCity(String city) {
		SendDataBean.city = city;
	}
	public static void setJson(String json) {
		SendDataBean.json = json;
	}
	public static void setAk(String ak) {
		SendDataBean.ak = ak;
	}
	public static String getCity() {
		return city;
	}
	public static String getJson() {
		return json;
	}
	public static String getAk() {
		return ak;
	}
	public static String getData() {
		return "http://api.map.baidu.com/telematics/v3/weather?location=" +
				city + "&output="+ json +"&ak="+ ak;
	}
	
	/**
	 * 百度API偶尔会出现服务器忙的情况，如果出现【302:request over】异常，则调用这个临时接口获取天气数据
	 * @return
	 */
	public static String getDataK780() {
		if(city==null||city.trim().length()==0){
			city="北京";
		}
		return "http://sapi.k780.com/?app=weather.future&appkey=10003&sign=b59bc3ef6191eb9f747dd4e83c99f2a4&format=json&jsoncallback=getWeather&weaid=" + city;
	}
	
	/**
	 * 备用接口2
	 * @return
	 */
	public static String getDataEtouch() {
		if(city==null||city.trim().length()==0){
			city="北京";
		}
		return "http://wthrcdn.etouch.cn/weather_mini?city=" + city;
	}
	
	/**
	 * 
	 * @return XML格式的数据，需要手动转为json格式数据
	 */
	public static String getDataEtouchFull() {
		if(city==null||city.trim().length()==0){
			city="南京";
		}
		return "http://wthrcdn.etouch.cn/WeatherApi?city=" + city;
	}
	 
//http://api.map.baidu.com/telematics/v3/weather?location=北京&output=json&ak=iGs8rFvzh1e8c7C9DjXT5toK

	
}
