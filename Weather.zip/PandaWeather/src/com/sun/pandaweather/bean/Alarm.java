package com.sun.pandaweather.bean;

public class Alarm {
    private String cityKey;//城市代码
    private String cityName;//城市名
    private String alarmType;//预警类型
    private String alarmDegree;//预警指数
    private String alarmText;//内容
    private String alarm_details;//详细信息
    private String standard;//提示
    private String suggest;//对策建议
    private String imgUrl;//图片
    private String time;//发布时间
    
	public String getCityKey() {
		return cityKey;
	}
	public void setCityKey(String cityKey) {
		this.cityKey = cityKey;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getAlarmType() {
		return alarmType;
	}
	public void setAlarmType(String alarmType) {
		this.alarmType = alarmType;
	}
	public String getAlarmDegree() {
		return alarmDegree;
	}
	public void setAlarmDegree(String alarmDegree) {
		this.alarmDegree = alarmDegree;
	}
	public String getAlarmText() {
		return alarmText;
	}
	public void setAlarmText(String alarmText) {
		this.alarmText = alarmText;
	}
	public String getAlarm_details() {
		return alarm_details;
	}
	public void setAlarm_details(String alarm_details) {
		this.alarm_details = alarm_details;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getSuggest() {
		return suggest;
	}
	public void setSuggest(String suggest) {
		this.suggest = suggest;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
    
}
