package com.sun.pandaweather.bean;

/**
 * 根据天气，返回对应的图片
 * 
 * @author hp
 *
 */
public class PictureUtils {
	private  static String baseUrl = "http://api.map.baidu.com/images/weather/";
	
	public static String picUrl(String weather,String daynight) {
		
		String icon = "duoyun.png";
		
		
		if("多云".equals(weather.trim())) {
			icon = "duoyun.png";
		}
		else if("雷阵雨".equals(weather.trim()))
		{
			icon = "leizhenyu.png";
		}
		else if("阵雨".equals(weather.trim()))
		{
			icon = "zhenyu.png";
		}
		else if("小雨".equals(weather.trim()))
		{
			icon = "xiaoyu.png";
		}
		else if("中雨".equals(weather.trim()))
		{
			icon = "zhongyu.png";
		}
		else if("大雨".equals(weather.trim()))
		{
			icon = "dayu.png";
		}
		else if("暴雨".equals(weather.trim()))
		{
			icon = "baoyu.png";
		}
		else if("大暴雨".equals(weather.trim()))
		{
			icon = "dabaoyu.png";
		}
		else if("晴".equals(weather.trim()))
		{
			icon = "qing.png";
		}
		else if("阴".equals(weather.trim()))
		{
			icon = "yin.png";
		}
		else if("小雪".equals(weather.trim()))
		{
			icon = "xiaoxue.png";
		}
		else if("中雪".equals(weather.trim()))
		{
			icon = "zhongxue.png";
		}
		else if("大雪".equals(weather.trim()))
		{
			icon = "daxue.png";
		}
		else if("暴雪".equals(weather.trim()))
		{
			icon = "baoxue.png";
		}
		else if("雾霾".equals(weather.trim())||"霾".equals(weather.trim()))
		{
			icon = "mai.png";
		}
		
		return baseUrl+daynight+"/"+icon;
	}
}
