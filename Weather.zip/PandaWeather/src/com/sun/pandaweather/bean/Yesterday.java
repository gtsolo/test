package com.sun.pandaweather.bean;

/**
 * 昨日天气
 *
 */
public class Yesterday {
    private String date_1;//日期
    private String high_1;//高温
    private String low_1;//低温
    
    private SimpleWeather day_1;//白天天气
    private SimpleWeather night_1;//夜间天气
    
	public String getDate_1() {
		return date_1;
	}
	public void setDate_1(String date_1) {
		this.date_1 = date_1;
	}
	public String getHigh_1() {
		return high_1;
	}
	public void setHigh_1(String high_1) {
		this.high_1 = high_1;
	}
	public String getLow_1() {
		return low_1;
	}
	public void setLow_1(String low_1) {
		this.low_1 = low_1;
	}
	public SimpleWeather getDay_1() {
		return day_1;
	}
	public void setDay_1(SimpleWeather day_1) {
		this.day_1 = day_1;
	}
	public SimpleWeather getNight_1() {
		return night_1;
	}
	public void setNight_1(SimpleWeather night_1) {
		this.night_1 = night_1;
	}
    
    
}
