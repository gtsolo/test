package com.sun.pandaweather.bean;

public class SimpleWeather2 {
	private String type;//天气
    private String fengxiang;//风向
    private String fengli;//风力
    
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getFengxiang() {
		return fengxiang;
	}
	public void setFengxiang(String fengxiang) {
		this.fengxiang = fengxiang;
	}
	public String getFengli() {
		return fengli;
	}
	public void setFengli(String fengli) {
		this.fengli = fengli;
	}
    
}
