package com.sun.pandaweather.bean;

public class Forecast {
	private String date;//日期
    private String high;//高温
    private String low;//低温
    
    private SimpleWeather2 day;//白天天气
    private SimpleWeather2 night;//夜间天气
    
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getHigh() {
		return high;
	}
	public void setHigh(String high) {
		this.high = high;
	}
	public String getLow() {
		return low;
	}
	public void setLow(String low) {
		this.low = low;
	}
	public SimpleWeather2 getDay() {
		return day;
	}
	public void setDay(SimpleWeather2 day) {
		this.day = day;
	}
	public SimpleWeather2 getNight() {
		return night;
	}
	public void setNight(SimpleWeather2 night) {
		this.night = night;
	}
    
}
