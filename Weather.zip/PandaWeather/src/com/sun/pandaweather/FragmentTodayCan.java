package com.sun.pandaweather;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.TextView;

import com.sun.pandaweather.adapter.GridTodayCAdapter;
import com.sun.pandaweather.bean.SportIndexBean;
import com.sun.pandaweather.bean.Zhishus;

public class FragmentTodayCan extends Fragment {

	public static final String TAG = "TodayCan";
	public TextView todaycan_dec;
	public Zhishus sib, sib1, sib2, sib3, sib4, sib5, sib6, sib7;
	public List<Zhishus> listsib;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		HomePagerActivity.TAG_H = TAG;
		View homep_content = inflater.inflate(R.layout.gridview_todaycan, null);

		GridView todayinfo_grid = (GridView) homep_content
				.findViewById(R.id.gridview);
		//描述text
		todaycan_dec = (TextView) homep_content.findViewById(R.id.todaycan_dec);
		listsib = HomePagerActivity.response.getZhishus();//.getResults().get(0).getIndex();
		Log.i("TAG", listsib.toString()+"==>>listsib.toString()");
		//因为成都的index数据为空
		if (HomePagerActivity.response.getZhishus().toString() == "[]") {
			Log.i("TAG", todaycan_dec.getText()+"==>>todaycan_dec");
			listsib.add(sib);
			listsib.add(sib1);
			listsib.add(sib2);
			listsib.add(sib3);
			listsib.add(sib4);
			listsib.add(sib5);
			listsib.add(sib6);
			listsib.add(sib7);
			todayinfo_grid.setAdapter(new GridTodayCAdapter(getActivity(), 
					HomePagerActivity.response.getZhishus()));
		}else {
			sib = new Zhishus();
			sib1 = new Zhishus();
			Calendar calendar = Calendar.getInstance();
			calendar.get(Calendar.YEAR);
			calendar.get(Calendar.MONTH +1);
			calendar.get(Calendar.DAY_OF_MONTH);

			sib.setValue("点击查看");
			sib1.setValue("点击查看");
			int month = calendar.get(Calendar.MONTH) +1;
			sib.setDetail("公(阳)历："+calendar.get(Calendar.YEAR)+"年"+
					month +"月"+
				calendar.get(Calendar.DAY_OF_MONTH)+"日"+"\n"+
				"农(阴)历：" + FragmentHomeContent.lunarStr);
			sib1.setDetail("雪山。西湖");
			//listsib.add(sib);
			//listsib.add(sib1);
			todaycan_dec.setText(sib.getDetail());
			
			listsib = HomePagerActivity.response.getZhishus();
			listsib.add(sib);
			todayinfo_grid.setAdapter(new GridTodayCAdapter(getActivity(),
					listsib));			
		}
		todayinfo_grid.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if(todaycan_dec.getText().equals("")){
					
				}else {
					if(position == 0){	
						todaycan_dec.setText(listsib.get(11).getDetail());//getValue是简要信息，getDetail()是详细信息
					}else if(position == 1){
						todaycan_dec.setText(listsib.get(0).getDetail());
					}else if(position == 2){
						todaycan_dec.setText(listsib.get(2).getDetail());
					}else if(position == 3){
						todaycan_dec.setText(listsib.get(7).getDetail());
					}else if(position == 4){
						todaycan_dec.setText(listsib.get(5).getDetail());
					}else if(position == 5){
						todaycan_dec.setText(listsib.get(3).getDetail());
					}else if(position == 6){
						todaycan_dec.setText(listsib.get(8).getDetail());
					}else if(position == 7){
						todaycan_dec.setText(listsib.get(6).getDetail());
					}
					/*if(position == 0){
						todaycan_dec.setText(listsib.get(position+6).getDes());
					}else if(position == 1){
						todaycan_dec.setText(listsib.get(position+6).getDes());
					}else {
						todaycan_dec.setText(listsib.get(position-2).getDes());
					}
					*/
				}
			}
		});
		return homep_content;
	}
	
}
