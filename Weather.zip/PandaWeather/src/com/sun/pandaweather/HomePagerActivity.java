package com.sun.pandaweather;

import java.io.IOException;

import net.sf.json.xml.XMLSerializer;

import org.apache.http.ParseException;
import org.apache.http.util.EntityUtils;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.GsonBuilder;
import com.sun.pandaweather.base.MHttpEntity;
import com.sun.pandaweather.bean.CityManagerBean;
import com.sun.pandaweather.bean.ResponseWrapper;
import com.sun.pandaweather.bean.SendDataBean;
import com.sun.pandaweather.view.MyProgressDialog;

public class HomePagerActivity extends FragmentActivity implements
		OnClickListener, FragmentAndActivity {
	private long nowtime;// 保存当前时间
	public static TextView bottom_weathertext;// 底部天气预报
	public static ResponseWrapper response = new ResponseWrapper();// 数据结构的对象
	public static ResponseWrapper response2;
	public static TextView bottom_citymanager;// 底部
	public static TextView bottom_todaycan;// 底部
	private static DrawerLayout drawerlayout_main;// drawerlayout_main
	private static View left_drawer;
	private EditText inputcity;//
//	private String inputcitytext;
	public static final int succeed = 1;
	public static final int fail = 2;
	public static final int nonet = 3;
	private static int tag = 0;
	public static String TAG_H = null;
	private Dialog dialog;
	public static FragmentHomeContent homecontent = new FragmentHomeContent();
	public FragmentCityManager citymanager = new FragmentCityManager();
	public static CityManagerBean cmb2 = new CityManagerBean();

	@Override
	protected void onResume() {
		SharedPreferences prefs=getSharedPreferences("config",MODE_PRIVATE);
		System.out.println(prefs);
		int num=prefs.getInt("bg_id", 0);
		if(num==0){
			rlRoot.setBackgroundResource(R.drawable.bg_homepager_blur);
		}else{
			rlRoot.setBackgroundResource(SkinActivity.skins[num]);
		}
		super.onResume();
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.homepager_main_activity);
	
		Intent intent = getIntent();
		String wetherdata = intent.getStringExtra("weather_data");// 得到启动页传递过来的数据
		GsonBuilder gson = new GsonBuilder();//
		response2 = gson.create().fromJson(wetherdata, ResponseWrapper.class);
		if(response2 != null){
			response = response2;
		}
		initview();
		
		FragmentManager fm = getSupportFragmentManager();
		FragmentTransaction ft = fm.beginTransaction();
		ft.replace(R.id.fragmentlayout, homecontent, FragmentHomeContent.TAG);
		ft.commit();

		bottom_weathertext.setTextColor(Color
				.parseColor(getString(R.string.color_bottombg)));
	}

	private void initview() {
		rlRoot = (RelativeLayout) findViewById(R.id.include_content);
		bottom_weathertext = (TextView) findViewById(R.id.bottom_weathertext);
		bottom_todaycan = (TextView) findViewById(R.id.bottom_todaycan);
		bottom_citymanager = (TextView) findViewById(R.id.bottom_citymanager);
		drawerlayout_main = (DrawerLayout) findViewById(R.id.drawerlayout_main);
		left_drawer = findViewById(R.id.left_drawer);
		drawerlayout_main.setScrimColor(0x00000000);// 设置底部页面背景透明度
		homeRefresh = (Button) findViewById(R.id.homep_refresh);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.homep_menu:
			openleftlayout();
			break;
		case R.id.homep_refresh:
			showDialog();
			bottom_weathertext.setTextSize(18);
			bottom_citymanager.setTextSize(16);
			bottom_todaycan.setTextSize(16);
			
			bottom_todaycan.setTextColor(Color
					.parseColor(getString(R.string.color_bottombgn)));
			bottom_citymanager.setTextColor(Color
					.parseColor(getString(R.string.color_bottombgn)));
			bottom_weathertext.setTextColor(Color
					.parseColor(getString(R.string.color_bottombg)));
			changepage(homecontent, FragmentHomeContent.TAG);
			new Thread(new Runnable() {

				@Override
				public void run() {
					sendRequest(FragmentHomeContent.currentcity.getText()
							.toString());
				}
			}).start();
			break;
		case R.id.bottom_todaycan:
			bottom_todaycan.setTextSize(18);
			bottom_citymanager.setTextSize(16);
			bottom_weathertext.setTextSize(16);
			
			bottom_todaycan.setTextColor(Color
					.parseColor(getString(R.string.color_bottombg)));
			bottom_citymanager.setTextColor(Color
					.parseColor(getString(R.string.color_bottombgn)));
			bottom_weathertext.setTextColor(Color
					.parseColor(getString(R.string.color_bottombgn)));
			homeRefresh.setVisibility(View.INVISIBLE);
			changepage(new FragmentTodayCan(), FragmentTodayCan.TAG);//sun
			break;
		case R.id.bottom_citymanager:
			bottom_citymanager.setTextSize(18);
			bottom_weathertext.setTextSize(16);
			bottom_todaycan.setTextSize(16);
			
			bottom_citymanager.setTextColor(Color
					.parseColor(getString(R.string.color_bottombg)));
			bottom_weathertext.setTextColor(Color
					.parseColor(getString(R.string.color_bottombgn)));
			bottom_todaycan.setTextColor(Color
					.parseColor(getString(R.string.color_bottombgn)));
			homeRefresh.setVisibility(View.INVISIBLE);
			changepage(citymanager, FragmentCityManager.TAG);
			
			
			break;
		case R.id.bottom_weathertext:
			bottom_weathertext.setTextSize(18);
			bottom_citymanager.setTextSize(16);
			bottom_todaycan.setTextSize(16);
			
			bottom_weathertext.setTextColor(Color
					.parseColor(getString(R.string.color_bottombg)));
			bottom_citymanager.setTextColor(Color
					.parseColor(getString(R.string.color_bottombgn)));
			bottom_todaycan.setTextColor(Color
					.parseColor(getString(R.string.color_bottombgn)));
			homeRefresh.setVisibility(View.VISIBLE);
			changepage(homecontent, FragmentHomeContent.TAG);
			break;
		case R.id.button1:
			Intent skIntent=new Intent(HomePagerActivity.this,SkinActivity.class);
			startActivity(skIntent);
			break;
		case R.id.button2:
			//中国天气网
			Uri uri = Uri.parse("http://m.weather.com.cn/mweather/101010100.shtml");
			Intent webIntent = new Intent(Intent.ACTION_VIEW, uri);
			startActivity(webIntent);
			break;
			
		case R.id.button4:
			//分享
			Intent intent = new Intent(Intent.ACTION_SEND);
			intent.setType("text/plain"); 
			intent.putExtra(Intent.EXTRA_TEXT, "熊猫天气,伴你同行！"); 
			startActivity(Intent.createChooser(intent, getTitle()));
//			Intent shareInent = new Intent(Intent.ACTION_VIEW);
//			shareInent.putExtra("sms_body", "熊猫天气真好用~");
//			shareInent.setType("vnd.android-dir/mms-sms");
//			startActivity(shareInent);
			break;
		case R.id.button5:
			//设置
			Intent settingIntent=new Intent(HomePagerActivity.this,SettingActivity.class);
			startActivity(settingIntent);
			break;
		case R.id.button6:
			//关于
			Intent aboutIntent=new Intent(HomePagerActivity.this,AboutActivity.class);
			startActivity(aboutIntent);
			break;
		case R.id.exitapp:
			finish();
			break;
		}
	}

	private void fromJson(String wetherdata) {
		GsonBuilder gson = new GsonBuilder();//
		response2 = gson.create().fromJson(wetherdata, ResponseWrapper.class);
		if (response2 != null) {
			response = response2;
			homecontent.setpagedata();
			if (tag == 4 && inputcity != null) {
				closeinput(inputcity);
			}
		} else {
			showToast(getString(R.string.getdata_fail));
		}
		if(FragmentHomeContent.dialog != null){
			FragmentHomeContent.dialog.dismiss();
		}
	}

	/**
	 * 点击多次bt，Toast只显示一次的解决方案
	 */
	public Toast toast = null;

	public void showToast(String text) {
		if (toast == null) {
			toast = Toast.makeText(this, text, Toast.LENGTH_SHORT);
		} else {
			toast.setText(text);
		}
		toast.show();
	}
	
	/**
	 * XML数据转化为json格式
	 * 
	 * @param xmlstr
	 * @return
	 */
	private String XML2Json(String xmlstr) {
		//创建 XMLSerializer对象
        XMLSerializer xmlSerializer = new XMLSerializer();
        //将xml转为json（注：如果是元素的属性，会在json里的key前加一个@标识）
        String result = xmlSerializer.read(xmlstr).toString();
        result = result.replaceAll("\\[\\]","\"\"");//空数组替换为空字符串
        return result;
	}

	/**
	 * 向服务器发送数据请求
	 */
	public void sendRequest(String cityname) {
		String getData = null;
		MHttpEntity mhe = null;
		try {
			SendDataBean.setCity(cityname);// 获取用户输入的城市名
			mhe = MHttpEntity.sendhttpclient(SendDataBean.getDataEtouchFull());
			//invalid city，说明城市输错
			if (mhe.getHentity() != null && mhe.getMessage().obj.toString().indexOf("invalid city")==-1) 
			{
				//getData = EntityUtils.toString(mhe.getHentity());
				mhe.getMessage().obj = XML2Json(mhe.getMessage().obj.toString());
			}
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (mhe.getMessage().obj.toString().indexOf("invalid city")==-1) 
		{
			handler.sendMessage(mhe.getMessage());// 使用Handler对网络状态做处理
		}
		else 
		{
			showToast("您的输入有误！");
		}
	}

	Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (dialog != null)
				dialog.dismiss();
			if (msg != null)
				switch (msg.arg1) {
				case succeed:// 与服务器连接成功
					if (msg.obj != null) {
						fromJson(msg.obj.toString());
					}
					break;
				case fail:// 与服务器连接失败
					showToast(getString(R.string.net_fail));
					break;
				}
		}
	};
	public static RelativeLayout rlRoot;
	private Button homeRefresh;

	/**
	 * 关联menu键
	 */
	public static void openleftlayout() {
		if (drawerlayout_main.isDrawerOpen(left_drawer)) {
			drawerlayout_main.closeDrawer(left_drawer);
		} else {
			drawerlayout_main.openDrawer(left_drawer);
		}
	}

	public void changepage(Fragment fragment, String str) {
		FragmentManager fm = getSupportFragmentManager();
		FragmentTransaction ft = fm.beginTransaction();// 开启一个事物，得到事物对象ft
		ft.replace(R.id.fragmentlayout, fragment, str);
		ft.commit();
	}

	/**
	 * 关闭输入法键盘
	 */
	public void closeinput(EditText editText) {
		editText.setText("");
		InputMethodManager imm = (InputMethodManager) 
				getSystemService(HomePagerActivity.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
	}

	/**
	 * 连续按两次返回则退出程序
	 */
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (System.currentTimeMillis() - nowtime > 2000) {
				Toast.makeText(this, R.string.click_exit, Toast.LENGTH_SHORT)
						.show();
				nowtime = System.currentTimeMillis();
				return true;
			} else {
				finish();
			}
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void senddata(EditText inputcity) {
		this.inputcity = inputcity;
	}

	@Override
	public void sendcitytext(final String inputcitytext) {
//		this.inputcitytext = inputcitytext;
		tag = 4;
		if ("".equals(inputcitytext)) {
			showToast(getString(R.string.edittext_hint));
			if(FragmentHomeContent.dialog != null){
				FragmentHomeContent.dialog.dismiss();
			}
		} else {
			SendDataBean.setCity(inputcitytext);// 获取用户输入城市
			new Thread(new Runnable() {

				@Override
				public void run() {
					sendRequest(inputcitytext);
				}
			}).start();
		}
	}

	@Override
	public void showDialog() {
		dialog =MyProgressDialog.createProgressDialog(HomePagerActivity.this,"正在更新..");
		dialog.setCancelable(true);// 点击可以取消Dialog的展现
		dialog.show();
	}
}
