package com.sun.pandaweather;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

public class SkinActivity extends Activity {
	private static List<ImageView> list;
	public static int[] skins = new int[] { R.drawable.bg_homepager_blur,
			R.drawable.bg_cloudy_day, R.drawable.bg_launch,
			R.drawable.bg_homepager, R.drawable.bg_snow, R.drawable.snow_bg };
	private PagerAdapter adapter;
	private ViewPager mViewPager;
	private int index = 0;
	private Button btn;
	SharedPreferences prefs;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_skin);
		prefs = getSharedPreferences("config", MODE_PRIVATE);
		initView();
	}

	private void initView() {
		list = new ArrayList<ImageView>();
		for (int i = 0; i < skins.length; i++) {
			ImageView img = new ImageView(this);
			img.setBackgroundResource(skins[i]);
			list.add(img);
		}

		adapter = new PagerAdapter() {

			@Override
			public boolean isViewFromObject(View arg0, Object arg1) {
				// TODO Auto-generated method stub
				return arg0==arg1;
			}

			@Override
			public int getCount() {
				// TODO Auto-generated method stub
				return list.size();
			}
			
			@Override
			public Object instantiateItem(ViewGroup container, int position) {
				container.addView(list.get(position));
				return list.get(position);
			}
			
			/** PagerAdapter只缓存3张要现实的图片，如果滑动超出了缓存的范围，就调用这个方法，将图片销毁掉 */
			@Override
			public void destroyItem(ViewGroup container, int position, Object object) {
				container.removeView(list.get(position));
			}
		};

		mViewPager = (ViewPager) findViewById(R.id.bg_vp);
		mViewPager.setAdapter(adapter);
		mViewPager.setPageMargin(100);
		mViewPager.setOnPageChangeListener(new OnPageChangeListener() {
			
			@Override
			public void onPageSelected(int position) {
				index=position;
			}
			
			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub
				
			}
		});

		btn = (Button) findViewById(R.id.btn_sel);
		btn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				prefs.edit().putInt("bg_id", index).commit();
				HomePagerActivity.openleftlayout();
				try {Thread.sleep(300);} catch (InterruptedException e) {e.printStackTrace();}
				finish();
			}
		});
	}
}