package com.sun.pandaweather;

import android.widget.EditText;


public interface FragmentAndActivity {

	public void senddata(EditText inputcity);
	public void sendcitytext(String inputcitytext);
	public void showDialog();
}
