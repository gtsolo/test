package com.sun.pandaweather;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.widget.GridView;

import com.sun.pandaweather.adapter.GridCityMAdapter;
import com.sun.pandaweather.bean.CityManagerBean;

public class CityManagerActivity extends Activity {

	private GridView mgridview;
	private List<CityManagerBean> mcmb;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gridview_activity);
		mcmb = new ArrayList<CityManagerBean>();
		CityManagerBean F = (CityManagerBean) FragmentHomeContent.mcmb;
		mcmb.add(F);
		mgridview = (GridView) findViewById(R.id.gridview);
		mgridview.setNumColumns(3);
		mgridview.setAdapter(new GridCityMAdapter(this, mcmb));
	}
}
